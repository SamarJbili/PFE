import pandas as pd
import os
import tempfile
import logging
from datetime import datetime
import re
import nltk
from bs4 import BeautifulSoup
import PyPDF2
import spacy
import docx
from PIL import Image
import pytesseract
import pdfplumber
import langdetect
from googletrans import Translator
import traceback

# Configuration du logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Charger le modèle spaCy en français
nlp = spacy.load("fr_core_news_md")

# Liste des mots-clés
keywords = ['compétence', 'formation', 'éducation', 'certification', 'expérience', 'expérience professionnelle']

# Fonction pour extraire du texte d'une image (OCR)
def extract_ocr_text(image_file):
    try:
        image = Image.open(image_file)
        text = pytesseract.image_to_string(image, lang='fra')
        return text
    except Exception as e:
        logger.error(f"OCR error: {str(e)}")
        return ""

def extract_pdf_text(pdf_file):
    try:
        with pdfplumber.open(pdf_file) as pdf:
            text = ""
            for page in pdf.pages:
                text += page.extract_text() or ""
            return text
    except Exception as e:
        logger.error(f"PDF extraction error: {str(e)}")
        return ""

def extract_docx_text(docx_file):
    try:
        doc = docx.Document(docx_file)
        text = ""
        for para in doc.paragraphs:
            text += para.text + '\n'
        return text
    except Exception as e:
        logger.error(f"DOCX extraction error: {str(e)}")
        return ""

def clean_text(text):
    """ Nettoyer le texte des espaces et caractères inutiles. """
    if not text:
        return ""
    return re.sub(r'\s+', ' ', text).strip()


def translate_to_french(text):
    """
    Traduit le texte en français s'il n'est pas déjà en français.

    Args:
        text (str): Le texte à traduire

    Returns:
        str: Le texte traduit en français, ou le texte original si déjà en français
    """
    # Vérifier si le texte est vide
    if not text or not isinstance(text, str):
        return ""

    try:
        # Détecter la langue du texte
        detected_lang = langdetect.detect(text)

        # Si le texte est déjà en français, le retourner tel quel
        if detected_lang == 'fr':
            return text

        # Initialiser le traducteur
        translator = Translator()

        # Traduire le texte en français
        translated = translator.translate(text, dest='fr')

        return translated.text

    except Exception as e:
        # Gestion des erreurs de traduction
        logger.error(f"Erreur de traduction : {str(e)}")
        return text  # Retourner le texte original en cas d'erreur


# Fonction à intégrer dans l'extraction de texte
def extract_text_and_translate(file_path):
    """
    Extrait le texte du fichier et le traduit en français si nécessaire.

    Args:
        file_path (str): Chemin du fichier à traiter

    Returns:
        str: Texte extrait et traduit en français
    """
    # Déterminer l'extension du fichier
    file_extension = os.path.splitext(file_path)[1].lower()

    # Extraire le texte selon le type de fichier
    if file_extension == '.pdf':
        text = extract_pdf_text(file_path)
    elif file_extension in ['.jpg', '.jpeg', '.png', '.tiff', '.bmp']:
        text = extract_ocr_text(file_path)
    elif file_extension == '.docx':
        text = extract_docx_text(file_path)
    else:
        logger.error(f"Type de fichier non supporté : {file_extension}")
        return ""

    # Nettoyer et traduire le texte
    cleaned_text = clean_text(text)
    translated_text = translate_to_french(cleaned_text)

    return translated_text
pdf_file = '/home/jbilisamar/Téléchargements/Back End Engineer.pdf'
translated_text = extract_text_and_translate(pdf_file)  # ✅ Passer le chemin du fichier
print(translated_text)


def save_text_to_file(text, filename="extracted_text.txt"):
    try:
        temp_dir = tempfile.mkdtemp()
        file_path = os.path.join(temp_dir, filename)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(text)

        logger.info(f"Fichier sauvegardé à : {file_path}")
        return file_path
    except Exception as e:
        logger.error(f"Erreur lors de la sauvegarde du texte dans le fichier : {str(e)}")
        return None

def extract_candidate_name(text):
    if not text or not isinstance(text, str):
        return None

    lignes = [ligne.strip() for ligne in text.split('\n') if ligne.strip()]
    if not lignes:
        return None

    first_line = lignes[0]
    if first_line.isupper():
        return first_line.strip()

    doc = nlp(first_line)
    noms = [ent.text for ent in doc.ents if ent.label_ == "PER"]

    if noms:
        return noms[0].strip()

    return first_line.strip()

def extract_phone(cv_text):
    phone_patterns = [
        r'(?:(?:\+|00)(?:33|216|1|44|49))\s*[1-9](?:[\s.-]*\d{1,2}){4,}',
        r'(?:0|\+)\s*[1-9](?:[\s.-]*\d{2}){4}',
        r'\d{2}[\s.-]?\d{2}[\s.-]?\d{2}[\s.-]?\d{2}[\s.-]?\d{2}',
        r'\+\d{3}\s*\d{2}\s*\d{2}\s*\d{2}\s*\d{2}'
    ]

    for pattern in phone_patterns:
        phone_matches = re.search(pattern, cv_text)
        if phone_matches:
            phone = phone_matches.group()
            phone = re.sub(r'[\s.-]', '', phone)
            if phone.startswith('00'):
                phone = '+' + phone[2:]
            elif phone.startswith('0') and not phone.startswith('+'):
                phone = '+33' + phone[1:]
            return phone

    return None


from datetime import datetime

import calendar

def extract_experience_years(cv_text):
    """
    Extrait les années d'expérience professionnelle
    - Calcul précis avec validation des dates
    - Gère différents formats de dates
    """
    if not cv_text or not isinstance(cv_text, str):
        return None

    # Dictionnaire des mois en français (pour les écritures en lettres)
    mois_dict = {
        'janvier': 1, 'jan': 1,
        'février': 2, 'fev': 2,
        'mars': 3,
        'avril': 4, 'avr': 4,
        'mai': 5,
        'juin': 6,
        'juillet': 7, 'jul': 7,
        'août': 8,
        'septembre': 9, 'sept': 9,
        'octobre': 10, 'oct': 10,
        'novembre': 11, 'nov': 11,
        'décembre': 12, 'dec': 12
    }

    # Normaliser le texte
    cv_text = cv_text.lower()

    # Variables pour le calcul
    current_year = datetime.now().year
    total_years = 0

    # Motifs de recherche spécifiques pour les années d'expérience
    experience_patterns = [
        # Recherche de mentions directes d'années d'expérience
        r'(\d+)\s*(?:ans|années|an|année)\s*d.expérience',

        # Recherche de plages de dates avec années
        r'(\d{4})\s*[-–]\s*(\d{4}|actuelle|présent|present)'
    ]

    # Calcul des années d'expérience
    for pattern in experience_patterns:
        matches = re.findall(pattern, cv_text, re.IGNORECASE)

        for match in matches:
            # Gestion des mentions directes d'années
            if len(match) == 1:
                years = int(match[0])
                total_years = max(total_years, years)

            # Gestion des plages de dates
            elif len(match) == 2:
                start_year = int(match[0])

                # Gestion de l'année de fin
                if match[1].lower() in ['actuelle', 'présent', 'present']:
                    end_year = current_year
                else:
                    end_year = int(match[1])

                # Validation et calcul
                if 1950 <= start_year <= end_year <= current_year:
                    experience_years = end_year - start_year
                    total_years = max(total_years, experience_years)

    return total_years if total_years > 0 else None

def extract_location(cv_text):
    location_patterns = [
        r'(?:Adresse|Address|Location|Localisation)\s*(?::|;)?\s*([^,\n]+(?:,\s*[^,\n]+){0,3})',
        r'(?:\n|^)([A-Z][a-zA-ZÀ-ÿ\s]+(?:,\s*[A-Z][a-zA-ZÀ-ÿ\s]+){1,2})(?:\n|$)',
        r'(\d+\s*(?:rue|avenue|boulevard|bd|place)\s+[^,\n]+(?:,\s*[^,\n]+){0,3})'
    ]

    for pattern in location_patterns:
        matches = re.search(pattern, cv_text, re.IGNORECASE)
        if matches:
            location = matches.group(1).strip()
            if not re.search(r'@|\+|\d{2}[\s.-]?\d{2}[\s.-]?\d{2}', location):
                parts = [part.strip() for part in location.split(',') if part.strip()]
                if len(parts) <= 3:
                    return ', '.join(parts)

    cities = ["Paris", "Lyon", "Marseille", "Tunis", "Sfax", "Sousse", "Casablanca", "Rabat", "Alger", "Oran"]

    for city in cities:
        city_pattern = rf'{city}\s*(?:,\s*|\s+-\s*|\s+)?'
        matches = re.search(city_pattern, cv_text, re.IGNORECASE)
        if matches:
            location = matches.group(0).strip()
            return location

    return None

def extract_education_level(cv_text):
    if not cv_text or not isinstance(cv_text, str):
        return None

    degree_mapping = {
        "bac[-+]?\\s*\\+?\\s*(8|7|6)": 8,
        "bac[-+]?\\s*\\+?\\s*5": 5,
        "bac[-+]?\\s*\\+?\\s*4": 4,
        "bac[-+]?\\s*\\+?\\s*3": 3,
        "bac[-+]?\\s*\\+?\\s*2": 2,
        "bac[-+]?\\s*\\+?\\s*1": 1,
        "ph[.]*d": 8,
        "doctorat": 8,
        "thèse": 8,
        "master\\s*2": 5,
        "master\\s*1": 4,
        "m2\\b": 5,
        "m1\\b": 4,
        "\\bmast[eè]re\\b": 5,
        "\\bmaster\\b": 5,
        "\\bmba\\b": 5,
        "\\bmsc\\b": 5,
        "ingénieur": 5,
        "ingé": 5,
        "école\\s*d['e]\\s*ingénieur": 5,
        "diplôme\\s*d['e]\\s*ingénieur": 5,
        "maîtrise": 4,
        "licence\\s*pro": 3,
        "licence": 3,
        "bachelor": 3,
        "bts": 2,
        "dut": 2,
        "deug": 2,
        "bac\\s*pro": 0,
        "bac\\s*technologique": 0,
        "bac\\s*général": 0,
        "baccalauréat": 0,
        "\\bbac\\b": 0,
    }

    normalized_text = ' '.join(cv_text.lower().split())
    current_level = None

    current_education_indicators = [
        r"niveau\s+d['e]\s*(?:formation|étude|qualification)[:]*\s*(\w+)",
        r"je\s+suis\s+diplômé\s+(?:de|d'une|du|d'un)\s+(\w+)",
        r"diplôme\s+(?:actuel|en\s+cours|obtenu)[:]*\s*(\w+)",
        r"titulaire\s+d['e]un[e]?\s+(\w+)",
        r"actuellement\s+en\s+(\w+)",
        r"j['e]\s+possède\s+un[e]?\s+(\w+)"
    ]

    for pattern in current_education_indicators:
        match = re.search(pattern, normalized_text)
        if match:
            stated_level = match.group(1)
            for degree_pattern, level in degree_mapping.items():
                if re.search(r'\b' + degree_pattern + r'\b', stated_level):
                    current_level = level
                    break
            if current_level is not None:
                break

    if current_level is not None:
        if current_level == 0:
            return "Baccalauréat"
        return f"Bac+{current_level}"

    found_degrees = []
    for degree_pattern, level in degree_mapping.items():
        if re.search(r'\b' + degree_pattern + r'\b', normalized_text):
            found_degrees.append((level, degree_pattern))

    if found_degrees:
        in_progress_indicators = [
            r"en\s+cours\s+d['e]\s*(\w+)",
            r"je\s+prépare\s+un[e]?\s+(\w+)",
            r"formation\s+non\s+terminée",
            r"diplôme\s+non\s+obtenu",
            r"étudiant\s+en\s+(\w+)",
            r"n['e]\s+pas\s+terminé"
        ]

        in_progress_degrees = []
        for pattern in in_progress_indicators:
            matches = re.finditer(pattern, normalized_text)
            for match in matches:
                if match.groups():
                    degree_mentioned = match.group(1)
                    for degree_pattern, level in degree_mapping.items():
                        if re.search(r'\b' + degree_pattern + r'\b', degree_mentioned):
                            in_progress_degrees.append((level, degree_pattern))

        if in_progress_degrees:
            for level, pattern in in_progress_degrees:
                found_degrees = [(l, p) for l, p in found_degrees if p != pattern]

        found_degrees.sort(reverse=True)

        if found_degrees:
            highest_level = found_degrees[0][0]
            if highest_level == 0:
                return "Baccalauréat"
            return f"Bac+{highest_level}"

    years_of_study_pattern = r"(\d+)\s*(ans|years?)\s*(?:d['e]\s*(?:formation|études)?)?"
    years_match = re.search(years_of_study_pattern, normalized_text)
    if years_match:
        years = int(years_match.group(1))
        if years >= 8:
            return "Bac+8 (Doctorat)"
        elif years == 7:
            return "Bac+7"
        elif years == 6:
            return "Bac+6"
        elif years == 5:
            return "Bac+5"
        elif years == 4:
            return "Bac+3"
        elif years == 3:
            return "Bac+2"
        elif years == 2:
            return "Bac+1"
        else:
            return "Baccalauréat"

    return None


import re


def extract_skills(cv_text):
    """
    Extrait les compétences de manière flexible
    - Recherche les mots 'compétence', 'compétences', 'compétence technique'
    - S'arrête à la rencontre de mots-clés de section suivante
    """
    if not cv_text or not isinstance(cv_text, str):
        return []

    # Normaliser le texte
    cv_text = cv_text.lower()

    # Mots-clés pour trouver la section des compétences
    skill_start_patterns = [
        r'compétence[s]*\s*[:]*\s*technique[s]*',
        r'compétence[s]*\s*[:]*',
        r'compétence[s]*\s*technique[s]*\s*:',
        r'skill[s]'
    ]

    # Liste étendue des mots-clés pour arrêter l'extraction
    stop_keywords = [
        # Sections administratives et personnelles
        'formation', 'éducation', 'education', 'expérience', 'experience',
        'formation académique', 'études', 'diplôme', 'certification',
        'projet académique', 'vie associative', 'langue', 'competence morale',

        # Sections professionnelles
        'emploi', 'poste', 'position', 'stage', 'alternance',
        'missions', 'responsabilités', 'réalisations',

        # Informations personnelles
        'coordonnées', 'contact', 'adresse', 'téléphone', 'email',
        'profil', 'objectif professionnel', 'motivation',

        # Développement personnel
        'centres d\'intérêt', 'loisirs', 'soft skills', 'compétences transversales',
        'compétences comportementales', 'qualités',

        # Autres sections
        'références', 'recommandations', 'parcours', 'historique',
        'activités', 'réalisations personnelles', 'distinctions',

        # Termes génériques
        'info', 'informations', 'détails', 'autre', 'autres'
    ]

    # Trouver l'index de départ des compétences
    start_match = None
    start_index = -1
    for pattern in skill_start_patterns:
        match = re.search(pattern, cv_text, re.IGNORECASE)
        if match:
            start_match = match
            start_index = match.end()
            break

    if start_index == -1:
        return []

    # Extraire le texte à partir de l'index de départ
    extracted_text = cv_text[start_index:]

    # Chercher le premier mot-clé d'arrêt
    stop_index = len(extracted_text)
    for keyword in stop_keywords:
        keyword_match = re.search(rf'\b{keyword}\b', extracted_text, re.IGNORECASE)
        if keyword_match:
            stop_index = min(stop_index, keyword_match.start())

    # Limiter le texte jusqu'au premier mot-clé d'arrêt
    skills_text = extracted_text[:stop_index]

    # Séparateurs pour extraire les compétences
    separators = [',', ';', '/', '•', '-', '\n']

    # Extraire les compétences
    skills = []
    for sep in separators:
        skill_list = [s.strip() for s in skills_text.split(sep)]

        # Filtrer les compétences
        filtered_skills = [
            skill for skill in skill_list
            if (skill
                and len(skill) > 2
                and not skill.isdigit()
                and not any(stop_keyword in skill.lower() for stop_keyword in stop_keywords)
                )
        ]

        skills.extend(filtered_skills)

    # Supprimer les doublons et retourner
    return list(dict.fromkeys(skills))


def extract_cv_info(cv_text):
    """
    Extraction des informations du CV avec gestion robuste des erreurs
    """
    # Définition du résultat par défaut avec des valeurs par défaut sûres
    result = {
        "Nom": "",
        "phone": "",
        "email": "",
        "education": "",
        "experience_years": 0,
        "location": "",
        "skills": []
    }

    # Validation initiale du texte
    if not cv_text or not isinstance(cv_text, str):
        logger.warning("Invalid CV text provided")
        return result

    # Nettoyage du texte
    cv_text = clean_text(cv_text)

    try:
        # Extraction des informations avec des valeurs par défaut
        result["Nom"] = extract_candidate_name(cv_text) or ""
        result["phone"] = extract_phone(cv_text) or ""
        result["skills"] = extract_skills(cv_text) or []

        # Extraction de l'email
        email_pattern = r'[\w\.-]+@[\w\.-]+\.\w+'
        email_matches = re.findall(email_pattern, cv_text)
        if email_matches:
            result["email"] = email_matches[0].lower()
            # Nettoyage de l'email si nécessaire
            result["email"] = re.sub(r'[^\w\.-@]', '', result["email"])

        # Autres extractions
        result["location"] = extract_location(cv_text) or ""
        result["education"] = extract_education_level(cv_text) or ""
        result["experience_years"] = extract_experience_years(cv_text) or 0

    except Exception as e:
        logger.error(f"Error extracting CV info: {str(e)}")
        logger.error(traceback.format_exc())

    return result


def process_cv(cv_file, file_type='pdf'):
    """
    Traitement du CV avec gestion complète des erreurs.
    Extrait, nettoie, traduit et structure les informations du CV.

    Args:
        cv_file (str): Chemin du fichier CV.
        file_type (str, optional): Type du fichier ('pdf', 'docx', 'image'). Par défaut 'pdf'.

    Returns:
        pd.DataFrame: DataFrame contenant les informations extraites du CV.
    """
    cv_text=""
    try:
        # Vérifier si le fichier existe
        if not os.path.isfile(cv_file):
            logger.error(f"Fichier introuvable: {cv_file}")
            return pd.DataFrame()

        # Extraire et traduire le texte du CV
        try:
            cv_text = extract_text_and_translate(cv_file)
            if not cv_text.strip():
                raise ValueError("Texte vide après extraction.")
        except Exception as e:
            logger.error(f"Erreur d'extraction/traduction du CV: {str(e)}")
            return pd.DataFrame()

        # Log du texte extrait (50 premiers caractères)
        logger.info(f"Extracted text (first 50 characters): {cv_text[:50]}")

        # Extraction des informations du CV
        cv_info = extract_cv_info(cv_text)

        # Gestion du nom si absent
        if not cv_info.get("Nom", "").strip():
            filename = os.path.basename(cv_file)
            name_match = re.search(r'CV[\s_-]*([\w\s]+)\.(pdf|docx|jpg|jpeg|png|tiff|bmp)', filename, re.IGNORECASE)
            cv_info["Nom"] = name_match.group(1).strip() if name_match else "Candidat Sans Nom"

        # Conversion des années d'expérience
        try:
            if cv_info.get("experience_years"):
                cv_info["experience_years"] = float(str(cv_info["experience_years"]).replace(',', '.'))
            else:
                cv_info["experience_years"] = 0  # Valeur par défaut
        except (ValueError, TypeError):
            logger.warning("Impossible de convertir experience_years en float.")
            cv_info["experience_years"] = 0

        # Log des informations extraites
        logger.info(f"Extracted CV information: {cv_info}")

        # Création du DataFrame
        cv_df = pd.DataFrame([cv_info])
        return cv_df

    except Exception as e:
        # Gestion complète des erreurs
        logger.error(f"Erreur lors du traitement du CV: {str(e)}")
        logger.error(traceback.format_exc())

        # Retour d'un DataFrame vide avec colonnes par défaut
        return pd.DataFrame([{
            "Nom": "Erreur Extraction",
            "phone": "",
            "email": "",
            "education": "",
            "experience_years": 0,
            "location": "",
            "skills": []
        }])