/** @odoo-module **/

import { KanbanController } from "@web/views/kanban/kanban_controller";
import { patch } from "@web/core/utils/patch";
import { useService } from "@web/core/utils/hooks";
import { rpc } from "@web/core/network/rpc";

// Patch du KanbanController
patch(KanbanController.prototype, {
    setup() {
        // Appeler la méthode originale si elle existe
        if (KanbanController.prototype.setup) {
            KanbanController.prototype.setup.call(this);
        }

        // Initialisation des services Odoo
        this.actionService = useService("action");
        this.notificationService = useService("notification");
    },

    redirectToDashboard() {
        this.actionService.doAction({
            type: 'ir.actions.act_window',
            name: 'Tableau de bord recrutement',
            res_model: 'hr.recruitment.dashboard',
            views: [[false, 'form']],
            target: 'new',
        });
    },

    async runAIAnalysis() {
        let jobId = 0;

        // Récupérer l'URL actuelle
        const pathName = window.location.pathname;
        console.log("URL path:", pathName);

        // Extraire l'ID de l'offre d'emploi depuis l'URL
        const recruitmentPathRegex = /\/(?:odoo\/)?recruitment\/(\d+)/;
        const match = pathName.match(recruitmentPathRegex);

        if (match && match[1]) {
            jobId = parseInt(match[1]);
            console.log("ID extrait du chemin:", jobId);
        }

        // Vérifier si l'ID n'a pas été trouvé et tenter de le récupérer depuis le modèle
        if (!jobId && this.model && this.model.root) {
            jobId = this.model.root.resId;
            console.log("ID récupéré du modèle:", jobId);
        }

        if (!jobId) {
            this.notificationService.add("Impossible de déterminer l'ID de l'offre d'emploi", {
                title: "Erreur",
                type: "danger",
            });
            return;
        }

        // Notification de chargement
        this.notificationService.add("Traitement des CVs en cours...", {
            title: "Analyse en cours",
            type: "info",
        });

        try {
            // Appel RPC pour analyser les CVs
            const analysisResult = await rpc("/recruitment/analyze_cvs", {
                job_id: jobId
            });

            console.log("Résultat de l'analyse:", analysisResult);

            if (!analysisResult.success) {
                throw new Error(analysisResult.message || "Échec de l'analyse des CVs");
            }

            // Télécharger le fichier CSV s'il est disponible
            if (analysisResult.csv_url) {
                window.location.href = analysisResult.csv_url;
                this.notificationService.add(`Analyse terminée (${analysisResult.cv_count || 0} CVs traités), téléchargement du fichier CSV en cours...`, {
                    title: "Succès",
                    type: "success",
                });
            }
        } catch (error) {
            console.error("Erreur lors de l'analyse et de l'évaluation:", error);
            this.notificationService.add(`Une erreur est survenue: ${error.message}`, {
                title: "Erreur",
                type: "danger",
            });
        }
    },
});
